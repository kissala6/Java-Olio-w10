package com.example.bottlemachine;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    WebView webse;
    EditText editTextTextPersonName;
    String address = "file:///android_asset/index.html";
    int currenti = 0;
    int secondry;
    int i;
    ArrayList<String> addressmem = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webse = findViewById(R.id.webse);
        editTextTextPersonName = (EditText)findViewById(R.id.editTextTextPersonName);
        webse.setWebViewClient(new WebViewClient());
        webse.getSettings().setJavaScriptEnabled(true);
        webse.loadUrl(address);
        editTextTextPersonName.setText(webse.getUrl());
        addressmem.add("file:///android_asset/index.html");
    }

    public void nappula(View v){
        currenti++;
        i = currenti;
        secondry = addressmem.size()-1;
        while(secondry >= i){
            addressmem.remove(i);
            i++;
        }
        addressmem.add("https://"+editTextTextPersonName.getText().toString()+"/");
        webse.loadUrl(addressmem.get(currenti));
        editTextTextPersonName.setText(webse.getUrl());
    }

    public void reverse(View v){
        currenti--;
        webse.loadUrl(addressmem.get(currenti));
        editTextTextPersonName.setText(webse.getUrl());
    }
    public void antireverse(View v){
        currenti++;
        webse.loadUrl(addressmem.get(currenti));
        editTextTextPersonName.setText(webse.getUrl());
    }
    public void reload(View v) {
        webse.loadUrl(addressmem.get(currenti));
        editTextTextPersonName.setText(webse.getUrl());
    }
    public void runscript1(View v){
        webse.evaluateJavascript("javascript:shoutOut()",null);
    }
    public void runscript2(View v){
        webse.evaluateJavascript("javascript:initialize()",null);
    }
}